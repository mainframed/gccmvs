/*********************************************************************/
/*                                                                   */
/*  This Program Written by Paul Edwards.                            */
/*  Released to the Public Domain                                    */
/*                                                                   */
/*********************************************************************/
/*********************************************************************/
/*                                                                   */
/*  fpfuncsc.c - some support routines for floating point work       */
/*  for IBM CSET compiler for OS/2                                   */
/*                                                                   */
/*********************************************************************/

int _fltused;

_exeentry(void)
{
    __main();
    return;
}
