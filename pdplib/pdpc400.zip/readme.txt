Public Domain C Library
-----------------------

Files included:

pdpclib.txt  - documentation for this archive
pdpgoal.txt  - philosophy of the Public Domain Project
*.c          - source code
*.asm        - source code
*.h          - header files
makefile.*   - various makefiles
compile.cmd  - command to execute makefiles for OS/2
compile.bat  - command to execute makefile for DOS
pdptest.*    - demo program
*.lib        - lib files for various compilers
pdpcms.bat   - build example program for CMS
pdpmts.bat   - build example program for MTS
pdpmus.bat   - build example program for MUSIC/SP
pdpmvs.bat   - build example program for MVS
pdpvse.bat   - build example program for DOS/VSE
