Open the gcc*.txt file and search for "gccmvs.txt" and
read that for MVS instructions. Also read "gcccms.txt"
if you wish to use CMS. And read "gccvse.txt" if you
wish to use VSE.
